const str='Hello World!';
Reverse=(data)=>{
 return  data.split('').reverse().join('');
}
 const res=Reverse(str);
 console.log(res);