const test=()=>{
  let a=0,b=10;
  while(true){
    // ++a
    console.log(a);
    if(a==0) break;
    console.log("??????")
    break;
  }
}
test()